export { initInsightsAnalytics } from "./insightsConsole";
