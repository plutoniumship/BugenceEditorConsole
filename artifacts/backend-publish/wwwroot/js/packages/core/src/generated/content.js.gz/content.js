/* eslint-disable */
/*
 * This file mirrors the Bugence Content API schema.
 * Regenerate with: pnpm exec openapi-typescript BugenceEditConsole/OpenApi/content.openapi.yaml --output packages/core/src/generated/content.ts
 */
export {};
